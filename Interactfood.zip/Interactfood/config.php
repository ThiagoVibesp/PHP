<?php    
$pulse_dir = "admin";
$page_title = "InteractFood";
$page_desc = "Descrição";
$logo_url = "img/logo.png";
$pulse_pass = "admin";
$height = "240";
$width = "240";
$blog_url = "blog.php";
$menu_home = "Home";
$menu_sobre = "Sobre";
$menu_cardapio = "Cardápio";
$menu_fotos = "Fotos";
$menu_blog = "Blog";
$menu_contato = "Contato";
$youtube_url = "UeD4kMNS5pQ";
$analytics_id = "UA-41206449-1";
$per_page = "4";
$blog_comments = true;
$blog_capcha = false;
$date_format = "d/m/Y";
$email_contact = "thramancio@gmail.com";
$telefone = "(85) 3254-5478";
$facebook_url = "https://www.facebook.com/";
$twitter_url = "https://twitter.com/";
$google_url = "https://plus.google.com/";
$linkedin_url = "https://www.linkedin.com/";
$pulse_lang = "PT_BR";
$custom_fieldname1 = "";
$custom_fieldname2 = "";
$formcap = "1";
$startpage = "manage-stats";

?>