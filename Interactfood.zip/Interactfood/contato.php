<?php include ("config.php");?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html lang="pt-br" class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        
        <title><?php echo $page_title; ?> - <?php echo $menu_contato; ?></title>
        <meta name="description" content="<?php echo $page_desc; ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/animations.css">
        <link rel="stylesheet" href="css/main.css">
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
        <!--[if lt IE 9]>
            <script src="js/vendor/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
    

                   
            </div>
        </div>
     </div>

    <header id="header" class="color_section">
        <div class="container">
            <div class="row">
                <a class="navbar-brand" href="/"><img src="<?php echo $logo_url; ?>" alt=""></a>
                <div class="col-sm-12 mainmenu_wrap">
                    <div class="main-menu-icon visible-xs">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <nav>
                        <ul id="mainmenu" class="menu sf-menu responsive-menu superfish">
                            <li class="">
                                <a href="/"><?php echo $menu_home; ?></a>
                            </li>
                            <li class="">
                                <a href="sobre"><?php echo $menu_sobre; ?></a>
                            </li>
                            <li class="">
                                <a href="cardapio"><?php echo $menu_cardapio; ?></a>
                             </li>  
                             <li class="">                                   
                                <a href="fotos"><?php echo $menu_fotos; ?></a>
                            </li> 
                            <li class="">                        
                                <a href="blog"><?php echo $menu_blog; ?></a>
                            </li>                      
                            <li class="active">
                                <a href="contato"><?php echo $menu_contato; ?></a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    

    
        <div class="container">
                        <div class="col-sm-12 text-center">
                    <h2 class="block-header">Fale Conosco</h2>
                    
                </div> 
            <div class="row">

              <div class="block widget_text col-sm-5 to_animate" data-animation="fadeInLeftBig">
                    <h3 class="contact-title">Informações</h3>
                  <?php include_once($_SERVER["DOCUMENT_ROOT"]."/admin/data/blocks/contato-info.html"); ?>

                    <h3>Encontre-nos no</h3>
                    <p id="social-bottom">
          <a class="socialico-facebook monochrome" href="<?php echo $facebook_url; ?>" target="_blank"  title="Facebook">#</a>     
          <a class="socialico-twitter monochrome" href="<?php echo $twitter_url; ?>" target="_blank"  title="Twitter">#</a>
          <a class="socialico-google monochrome" href="<?php echo $google_url; ?>" target="_blank"  title="Google">#</a>
          <a class="socialico-linkedin monochrome" href="<?php echo $linkedin_url; ?>" target="_blank" title="Lindedin">#</a>
                    </p>
                </div>

                <div class="block col-sm-7 to_animate" data-animation="fadeInRightBig">
                    <h3 class="contact-title">Formulário de Contato</h3>
<form action="enviar.php" method="POST">
<input type="hidden">
Nome:<br /> <input type="text" size="30" name="nome" value=""><br />
E-mail:<br /> <input type="text" size="30" name="email" value="">   <br />
Assunto:<br /> <input type="text" size="30" name="assunto" value="">      <br />
Mensagem:<br />
<textarea cols="40" rows="10" name="mensagem"></textarea> <br />
<input name="submit" type="submit" value=" Enviar "> &nbsp; <input name="reset" type="reset" value=" Limpar ">
</form>
</br>
</br>

                </div>
              
            </div>
        </div>

    

<footer id="footer" class="dark_section">
  <div class="container">    
    <div class="row">  

      <div class="block col-md-3 col-sm-6 flickr_widget to_animate" data-animation="fadeInLeftBig">
      <h3>Vídeo Institucional</h3>
      <ul >
         <iframe src="https://www.youtube.com/embed/<?php echo $youtube_url; ?>" frameborder="0" width="100%" height="auto"></iframe></ul>
    </div>

      <div class="block widget_text col-md-3 col-sm-6 to_animate" data-animation="fadeInLeftBig">
        <h3>Informações</h3>
        <?php include_once($_SERVER["DOCUMENT_ROOT"]."/admin/data/blocks/rodape/informacoes.html"); ?>
        <p>
          <a class="socialico-twitter" href="<?php echo $twitter_url; ?>" target="_blank"  title="Twitter">#</a>
          <a class="socialico-facebook" href="<?php echo $facebook_url; ?>" target="_blank"  title="Facebook">#</a>
          <a class="socialico-google" href="<?php echo $google_url; ?>" target="_blank"  title="Google">#</a>
          <a class="socialico-linkedin" href="<?php echo $linkedin_url; ?>" target="_blank" title="Lindedin">#</a>
        </p>
      </div>   

      <div class="block col-md-3 col-sm-6 to_animate" data-animation="fadeInRightBig">
      <div class="block widget_news">
        <h3>Posts mais Recentes</h3>
        <ul>
            <li class="item">
<?php include_once($_SERVER["DOCUMENT_ROOT"]."/admin/includes/blog-home.php"); ?>
<a class="btn-default btn2" href="blog">Mais Posts</a>
            </li>
          </ul>
      </div>
    </div>

   <div class="block col-md-3 col-sm-6 subscribe to_animate" data-animation="fadeInRightBig">
      <h3>Comentários</h3>
      <?php include_once($_SERVER["DOCUMENT_ROOT"]."/admin/data/blocks/rodape/comentario.html"); ?>

    </div>       
    </div>
  </div>
</footer>

    <section id="copyright" class="color_section">
        <div class="container">
            <div class="row">

                <div class="col-sm-12 text-center">
				<?php include_once($_SERVER["DOCUMENT_ROOT"]."/admin/data/blocks/rodape/copyright.html"); ?>
                </div>
            </div>

        </div>
    </section>
 

    <div class="preloader">
        <div class="preloaderimg"></div>
    </div>

        <script src="js/vendor/jquery-1.11.1.min.js"></script>
        <script src="js/vendor/jquery-migrate-1.2.1.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/placeholdem.min.js"></script>
        <script src="js/vendor/hoverIntent.js"></script>
        <script src="js/vendor/superfish.js"></script>
        <script src="js/vendor/jquery.actual.min.js"></script>
        <script src="js/vendor/jquery.appear.js"></script>
        <script src="js/vendor/jquerypp.custom.js"></script>
        <script src="js/vendor/jquery.elastislide.js"></script>
        <script src="js/vendor/jquery.flexslider-min.js"></script>
        <script src="js/vendor/jquery.prettyPhoto.js"></script>
        <script src="js/vendor/jquery.easing.1.3.js"></script>
        <script src="js/vendor/jquery.ui.totop.js"></script>
        <script src="js/vendor/jquery.isotope.min.js"></script>
        <script src="js/vendor/jquery.easypiechart.min.js"></script>
        <script src='js/vendor/jflickrfeed.min.js'></script>
        <script src="js/vendor/jquery.sticky.js"></script>
        <script src='js/vendor/owl.carousel.min.js'></script>
        <script src='js/vendor/jquery.nicescroll.min.js'></script>
        <script src='js/vendor/jquery.fractionslider.min.js'></script>
        <script src='js/vendor/jquery.scrollTo-min.js'></script>
        <script src='js/vendor/jquery.localscroll-min.js'></script>
        <script src='js/vendor/jquery.parallax-1.1.3.js'></script>
        <script src='js/vendor/jquery.bxslider.min.js'></script>
        <script src='js/vendor/jquery.funnyText.min.js'></script>
        <script src='js/vendor/jquery.countTo.js'></script>
        <script src="js/vendor/grid.js"></script>
        <script src='twitter/jquery.tweet.min.js'></script>
        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>
		<script src="/admin/includes/tracker.php?uri=<?php echo $_SERVER['REQUEST_URI']; ?>&ref=<?php echo $_SERVER['HTTP_REFERER']; ?>"></script>
		<script type="text/javascript">

  var _gaq = _gaq || [];

  _gaq.push(['_setAccount', '<?php echo $analytics_id; ?>']);

  _gaq.push(['_trackPageview']);



  (function() {

    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;

    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';

    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);

  })();

</script>

    </body>
</html>