<?php include ("config.php"); ?> 

<?

$nome      = $_POST["nome"];
$email   = $_POST["email"];
$assunto   = $_POST["assunto"];
$mensagem  = $_POST["mensagem"];

global $email;

$data      = date("d/m/y");
$ip        = $_SERVER['REMOTE_ADDR'];
$navegador = $_SERVER['HTTP_USER_AGENT'];
$hora      = date("H:i");

mail ("$email_contact",
"$assunto",
"Nome: $nome\nData: $data\nIp: $ip\nNavegador: $navegador\nHora: $hora\n $site\nE-mail: $email\n $fone\n\nMensagem: $mensagem",
"From: $email"
);

$site   = "$email_contact";
$titulo = "$page_title - Contato";
$msg    = "$nome, obrigado por entrar em contato conosco, em breve entraremos em contato!";

mail("$email",
"$titulo",
"$msg",
"From: $site"
);
echo "<p align=center>$nome, sua mensagem foi enviada com sucesso!</p>";
echo "<p align=center>Estaremos retornando em breve.</p>";

?>
<html>
<head>
<META HTTP-EQUIV=Refresh CONTENT="3; URL=/contato">
</head>
<body>
</body>