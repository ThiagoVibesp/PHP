﻿
<!DOCTYPE html>
<html>
<head>
	<title><?php echo $lang_page_title; ?></title>
	<meta charset="utf-8" />
	
	<link rel="stylesheet" href="http://<?php echo $o; ?>/admin/css/style.css" media="all" />
	<?php include('hide.php');?>
    
	<link rel="stylesheet" href="http://<?php echo $o; ?>/admin/plugins/plupload/jquery.plupload.queue/css/jquery.plupload.queue.css" media="all" />
	<link rel="stylesheet" href="http://<?php echo $o; ?>/admin/plugins/redactor/css/redactor.css" />
	
	<meta name = "viewport" content = "initial-scale = 1.0, maximum-scale = 1.0, minimal-ui">
	
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/ios-icon-precomposed.png" />
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/ios-sm-precomposed.png" />
     

	<script src="http://<?php echo $o; ?>/admin/plugins/jquery/jquery.min.js"></script>
	<script src="http://<?php echo $o; ?>/admin/plugins/redactor/redactor.min.js"></script>
	<script src="http://<?php echo $o; ?>/admin/plugins/jquery/jquery_ui.js"></script>
	
	<script src="http://<?php echo $o; ?>/admin/plugins/redactor/pt_br.js"></script> 
	
	<!-- Redactor's plugin -->
    <script src="http://<?php echo $o; ?>/admin/plugins/redactor/fullscreen.js"></script>
    <script src="http://<?php echo $o; ?>/admin/plugins/redactor/fontsize.js"></script>
    <script src="http://<?php echo $o; ?>/admin/plugins/redactor/fontfamily.js"></script>
    <script src="http://<?php echo $o; ?>/admin/plugins/redactor/fontcolor.js"></script>
    

	
	<script>
		$(document).ready(function(){
			$('a.embed_toggle').on('click', function(e) {    
			e.preventDefault();    
			$('#main').slideToggle(400);})		
		});
	</script>
	
	<script> 
		if (!RedactorPlugins) var RedactorPlugins = {};
		RedactorPlugins.morebutton = {
			init: function ()
			{
				this.buttonAdd('morebutton', 'Insira LEIA MAIS botão para blog.', this.testButton);
			},
			testButton: function(buttonName, buttonDOM, buttonObj, e)
			{
				this.insertHtml('##mais##');
			}
		};
	</script>
	
	<script>
		$(function()
		{
			$('#redactor_content').redactor({
				lang: 'pt_br',
				imageUpload: 'includes/editor_images.php',
				imageGetJson: 'includes/data_json.php',
				fileUpload: 'includes/editor_files.php',
				convertDivs: false,
				autoresize: true,
				minHeight: 350,
				phpTags: true,
				linkEmail: true,
				plugins: ['fullscreen','fontsize','fontfamily','fontcolor', 'morebutton']
			});
		});
	</script>
    

	
</head>
	
<body id="<?php echo $page ?>">

<script> 
	function select_all(obj) 
		{ var text_val=eval(obj); 
			text_val.select(); 
		} 
</script>
		
<div id="header" class="group">
	<div class="inner">

		<a href="./"><div class="logo"></div></a>
			
		<ul id="pulse-nav">
			
			<li class="nav-blocks"><a href="http://<?php echo $o; ?>/admin/index.php?p=manage-blocks">Páginas</a></li>
			<li class="nav-blog"><a href="http://<?php echo $o; ?>/admin/index.php?p=manage-blog">Blog</a></li>
			<li class="nav-gallery"><a href="http://<?php echo $o; ?>/admin/index.php?p=manage-gallery"><?php echo $lang_nav_galleries; ?></a></li>
			
			<li class="nav-stats"><a href="http://<?php echo $o; ?>/admin/index.php?p=manage-stats"><?php echo $lang_nav_stats; ?></a></li>
			<li class="nav-backup"><a href="http://<?php echo $o; ?>/admin/index.php?p=manage-backups"><?php echo $lang_nav_backup; ?></a></li>
			<li class="nav-settings"><a href="http://<?php echo $o; ?>/admin/index.php?p=settings"><?php echo $lang_nav_settings; ?></a></li>
		</ul>

	</div>
</div>
