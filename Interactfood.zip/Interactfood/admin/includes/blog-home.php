<?php



error_reporting(0);



include_once("path.php");

include_once(ROOTPATH."../../config.php");

include_once("lang/$pulse_lang.php");

include_once("helpers/functions.php");

include_once("helpers/blog_lib.php");



$get_blog = new show_Blogs;

$captcha  = new read_Cap;

$order    = ($date_format=='0' || $date_format=='1') ? "d-m-Y" : $date_format;

?> 



<link rel="stylesheet" href="http://<?php echo $_SERVER['HTTP_HOST']; ?>/<?php echo $pulse_dir; ?>/css/blog-home.css">



<?php



echo "<div class='blog-home-wrap'> \n";



if ($get_blog->val_d($_GET["d"]) == true) {

    $id_post  = super_clean($_GET["d"]);


    $x        = 0;

	$resp     = ($blog_capcha == false) ? 1 : $q_and_a[0];





	$blog_post_content = $get_blog->get_blog_post($id_post);			

	$blog_turned_off   = ($blog_post_content[7] == 1) ? true : false;

	

	if ($blog_post_content[0] == 0){ echo "404 Not Found"; header($_SERVER['SERVER_PROTOCOL'].' 404 Not Found'); die(); }

	

	// Display individual post
// Show all posts

foreach ($get_blog->get_blog_posts($per_page, $lang_blog_more) as $post) {

	echo "<div class='entry-home'>\n";

	echo "<h2 class='blog-home-title'><a href=\"blog-$post[0]-$post[3]\">$post[5]</a></h2>\n"; 

    echo "<div class='blog-home-date'>".date($order, strtotime($post[2]))."</div>\n";

	echo "</div>\n";

}
  
} else { 


// Show all posts

foreach ($get_blog->get_blog_posts($per_page, $lang_blog_more) as $post) {

	echo "<div class='entry-home'>\n";

	echo "<h2 class='blog-home-title'><a href=\"blog-$post[0]-$post[3]\">$post[5]</a></h2>\n"; 

    echo "<div class='blog-home-date'>".date($order, strtotime($post[2]))."</div>\n";


    if ($blog_comments) {				

        
         if ($post[1]) { ; } else {  }

     }

	echo "</div>\n";

}

}

echo '</div>';

?>