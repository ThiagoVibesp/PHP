<form action = "index.php?p=settings" method = "post">

<div id = "sub-head">
	<button type = "submit"><?php echo $lang_blog_button_update; ?></button>
	<?php greenCheckmark();?>
</div>

<div id = "content">

<?php
require_once("login.php");

if ($_POST["status"] == 1) {		

     if (isset($_SESSION["token"]) 
        && isset($_SESSION["token_time"]) 
        && isset($_POST["token"]) 
        && $_SESSION["token"] == $_POST["token"]) {
        
        $timestamp_old = time() - (60*60);

        if ($_SESSION["token_time"] >= $timestamp_old) {
	   
	        foreach ($_POST as $var => $key) {
                $$var = htmlspecialchars(trim(stripslashes($key)), ENT_QUOTES, "UTF-8");
            }

	        $config = '<?php    
$pulse_dir = "'. $directory .'";
$page_title = "'. $page_title .'";
$page_desc = "'. $page_desc .'";
$logo_url = "'. $logo_url .'";
$pulse_pass = "'. $password .'";
$height = "'. $height .'";
$width = "'. $width .'";
$blog_url = "'. $blog_url .'";
$menu_home = "'. $menu_home .'";
$menu_sobre = "'. $menu_sobre .'";
$menu_cardapio = "'. $menu_cardapio .'";
$menu_fotos = "'. $menu_fotos .'";
$menu_blog = "'. $menu_blog .'";
$menu_contato = "'. $menu_contato .'";
$youtube_url = "'. $youtube_url .'";
$analytics_id = "'. $analytics_id .'";
$per_page = "'. $posts_per .'";
$blog_comments = '. $comments .';
$blog_capcha = '. $blog_capcha .';
$date_format = "'. $date_format .'";
$email_contact = "'. $email .'";
$telefone = "'. $telefone .'";
$facebook_url = "'. $facebook_url .'";
$twitter_url = "'. $twitter_url .'";
$google_url = "'. $google_url .'";
$linkedin_url = "'. $linkedin_url .'";
$pulse_lang = "'. $pulse_lang .'";
$custom_fieldname1 = "'. $custom_fieldname1 .'";
$custom_fieldname2 = "'. $custom_fieldname2 .'";
$formcap = "'. $formcap .'";
$startpage = "'. $startpage .'";

?>';

            if ($fp = fopen("../config.php", "w")) {
                fwrite($fp, $config, strlen($config));
                
                $_SESSION["saved"]=true;
                $host  = $_SERVER['HTTP_HOST'];
				$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
				header("Location: http://$host$uri/index.php?p=settings");
				die();
				
            } else {
                echo "<p class=\"errorMsg\">$lang_settings_unwritable</p>"; 
            }
        }       
    }
}

if (empty($_SESSION["token"]) || $_SESSION["token_time"] <= $timestamp_old){
		 $_SESSION["token"]      = md5(uniqid(rand(), TRUE));	
		 $_SESSION["token_time"] = time();
}

if (!isset($_POST["status"])) {
?>
    
    
 <style>

.accordion {
  padding: 0;
  margin: 2em 0;
  width: 100%;
  overflow: hidden;
  font-size: 1em;
  position: relative;
}

.accordion__title {
  padding: 0 1em;
  background: #ccc;
  border-top: 2px solid #eee;
  color: #222;
  float: left;
  line-height: 3;
  height: 3em;
  cursor: pointer;
  margin-right: .25em;
}

.no-js .accordion__title {
  float: none;
  height:auto;
  cursor:auto;
  margin:0;
  padding:0 2em;
}

.accordion__content {
  float: right;
  width: 100%;
  margin: 3em 0 0 -100%;
  padding: 0;
  background: fff;
}

.no-js .accordion__content {
  float:left;
  margin:0;
}

.accordion__title:hover,
.accordion__title.active {
  background: silver;
  color: white;
}

.no-js .accordion__title:hover {
  background-color:#ccc;
  color:#222;
}

.accordion__title.active {
  border-top-color:lime;
}

@media (max-width: 48em) {
  
  .accordion {
    border: 1px solid grey;
  }
  
  .accordion__title,
  .accordion__content { 
    float: none;
    margin: 0;
  }
  
  .accordion__title:first-child {
    border:none;
  }
  
 .accordion__title.active {
  border-top-color:#eee;
  }
  
  .accordion__title.active, .accordion__title:hover {
    background:#777;
  }
  
  .accordion__title:before {
  content:"+";
  text-align:center;
  width:2em;
  display:inline-block;
  }
 .accordion__title.active:before {
  content:"-";
  }
  
 .overflow-scrolling {
  overflow-y: scroll;
  height:11em;
  padding:1em 1em 0 1em;
  /* Warning: momemtum scrolling seems buggy on iOS 7  */
  -webkit-overflow-scrolling: touch;
  }

  .accordion__content {
    position:relative;
    overflow:hidden;
    padding:0;
  }
  
   .no-js .accordion__content {
    padding:1em;
    overflow:auto;
    display:block;
  }
  
  .accordion__content:after {
    position:absolute;
    top:100%;
    left:0;
    width:100%;
    height:50px;
    border-radius:10px 0 0 10px / 50% 0 0 50%;
    box-shadow:-5px 0 10px rgba(0, 0, 0, 0.5);
    content:'';
}
   
}
</style>   
    
    <dl class="accordion">
    
      <dt class="accordion__title">Geral</dt>
  <dd class="accordion__content">
<div class="settings">
   <br>
   <h2><?php echo $lang_setting_general; ?></h2>
   
   <div class="setting">
	   <label><?php echo $lang_setting_folder; ?></label>
	   <input class="med" type="text" name="directory" value="<?php echo $pulse_dir; ?>"/>
	   <p class="settings-hints"><?php echo $lang_setting_folder_hint; ?></p>
   </div>
     
 
   
   <div class="setting">
	    <label>Título do Site</label>
	    <input class="long "type="text" name="page_title" value="<?php echo $page_title; ?>" />
    </div>

    
    
       <div class="setting">
	    <label>Descrição do Site</label>
	    <input class="long "type="text" name="page_desc" value="<?php echo $page_desc; ?>" />
    </div>
    
           <div class="setting">
	    <label>Url da logo</label>
	    <input class="long "type="text" name="logo_url" value="<?php echo $logo_url; ?>" />
    </div>
   
   <div class="setting">
	   <label><?php echo $lang_setting_password; ?></label>
	   <input class="med" type="password" name="password" value="<?php echo $pulse_pass; ?>"/>
   </div>
   
   <div class="setting">
	   <label><?php echo $lang_email_contact; ?></label>
	   <input class="med" type="text" name="email" value="<?php echo $email_contact; ?>"/>
   </div>
      <div class="setting">
	   <label>Telefone:</label>
	   <input class="med" type="text" name="telefone" value="<?php echo $telefone; ?>"/>
   </div>
   
   <div class="setting">
	   <label><?php echo $lang_setting_lang; ?></label>
	   <select name="pulse_lang">
	   
	   <?php 	   
	   foreach ((glob("includes/lang/*")) as $language) {
		   $language = explode("/", $language);
		   $language = explode(".", $language[2]);	
		   $language_collection[] = $language[0];
		 }

		foreach($language_collection as $lang_option){

		?><option value = "<?php echo $lang_option; ?>"<?php echo $pulse_lang == $lang_option ? 'selected="selected"' : '';?>><?php echo ucfirst($lang_option); ?></option><?php
		   			   		
			  } ?>
	   
	   </select> 
   </div>
   
      <div class="setting">
	   <label><?php echo $lang_blocks_home; ?></label>
	   <select name="startpage">
	   
	   <?php 	
	   $startpage_options = array(
	   		array($lang_nav_pages,'manage-pages'), 
	   		array($lang_nav_blocks,'manage-blocks'), 
	   		array($lang_nav_blog,'manage-blog'), 
	   		array($lang_nav_galleries,'manage-gallery'), 
	   		array($lang_nav_form,'manage-form'), 
	   		array($lang_nav_stats,'manage-stats'), 
	   		array($lang_nav_backup,'manage-backups'), 
	   		array($lang_nav_settings,'settings') 
	   		);
	      
	   foreach ($startpage_options as $startpage_option) {

		?><option value = "<?php echo $startpage_option[1]; ?>"<?php echo $startpage == $startpage_option[1] ? 'selected="selected"' : '';?>><?php echo ucfirst($startpage_option[0]); ?></option><?php
		   			   		
			  } ?>
	   
	   </select> 
   </div>
</dd>

      <dt class="accordion__title">Social</dt>
  <dd class="accordion__content">
      <div class="settings">
    <br>
    
    <h2>Social</h2>


   <div class="setting">
	   <label>Facebook</label>
	   <input class="long" type="text" name="facebook_url" value="<?php echo $facebook_url; ?>"/>
	   <p class="settings-hints">Coloque o url do Facebook</p>
   </div>
   <div class="setting">
	   <label>Twitter</label>
	   <input class="long" type="text" name="twitter_url" value="<?php echo $twitter_url; ?>"/>
	   <p class="settings-hints">Coloque o url do Twitter</p>
   </div>
   
   <div class="setting">
	   <label>Google+</label>
	   <input class="long" type="text" name="google_url" value="<?php echo $google_url; ?>"/>
	   <p class="settings-hints">Coloque o url do Google+</p>
   </div>
      <div class="setting">
	   <label>linkedin</label>
	   <input class="long" type="text" name="linkedin_url" value="<?php echo $linkedin_url; ?>"/>
	   <p class="settings-hints">Coloque o url do linkedin</p>
   </div>

     <div class="setting">
	   <label>Youtube ID</label>
	   <input class="long" type="text" name="youtube_url" value="<?php echo $youtube_url; ?>"/>
	   <p class="settings-hints">Coloque o ID do vídeo do youtube o Exemplo https://www.youtube.com/watch?v=<strong>hnJPHYAlid8</strong> copie do link somente o ID como mostra em negrito "hnJPHYAlid8". Esse vídeo aparecerá na página principal</p>
   </div>
   
        <div class="setting">
	   <label>Analytics ID</label>
	   <input class="long" type="text" name="analytics_id" value="<?php echo $analytics_id; ?>"/>
	   <p class="settings-hints">Coloque o ID do Google Analytics</p>
   </div>
  
  </dd>


      <dt class="accordion__title">Galeria</dt>
  <dd class="accordion__content">
  <br>
    <h2><?php echo $lang_setting_gallery_thumbnails; ?></h2>
    
    <div class="setting">
    	<span><?php echo $lang_setting_tim_height; ?></span>
    	<input name="height" type="text" style="width:75px" placeholder="100" value="<?php echo $height; ?>" >
    	<span><?php echo $lang_setting_tim_width; ?></span>
    	<input name="width" type="text" style="width:75px" placeholder="100" value="<?php echo $width; ?>" >
    </div>
       </dd>
       

          <dt class="accordion__title">Blog</dt>
  <dd class="accordion__content">
  <br>
    <h2><?php echo $lang_setting_blog; ?></h2>
    
    <div class="setting">
	    <label><?php echo $lang_setting_blog_url; ?></label>
	    <input class="long "type="text" name="blog_url" value="<?php echo $blog_url; ?>" />
	    <p class="settings-hints"><?php echo $lang_setting_blog_url_hint; ?></p>
    </div>
    
    <div class="setting">
	    <label><?php echo $lang_setting_blog_posts; ?></label>
	    <input type="text" name="posts_per" value="<?php echo empty($per_page) ? 5 : $per_page; ?>" />
    </div>
    
    <div class="setting">
    <?php if( ($date_format == '0') || ($date_format == '1')){ $date_format = 'd-m-Y';}?>
	    <label ><?php echo $lang_setting_date; ?></label>
		<input type="text" name="date_format" value="<?php echo $date_format; ?>"/>
		<p class="settings-hints"><?php echo $lang_setting_blog_date; ?></p>
    </div>
    
    <div class="setting">
	    <label><?php echo $lang_setting_blog_comments; ?></label>
	    <select name="comments">
	    	<option value="true" <?php echo ($blog_comments) ? 'selected="selected"' : '';?>><?php echo $lang_setting_blog_enabled; ?></option>
	    	<option value="false" <?php echo ($blog_comments) ? '' : 'selected="selected"';?>><?php echo $lang_setting_blog_disabled; ?></option>
	    </select>
    </div>
    
    <div class="setting">
	    <label><?php echo $lang_blog_capcha ?></label>
	    <select name="blog_capcha">
	    	<?php if (!isset ($blog_capcha)) { $blog_capcha = true; } ?>
	    	<option value="true" <?php echo ($blog_capcha) ? 'selected="selected"' : '';?>><?php echo $lang_setting_blog_enabled; ?></option>
	    	<option value="false" <?php echo ($blog_capcha) ? '' : 'selected="selected"';?>><?php echo $lang_setting_blog_disabled; ?></option>
	    </select>
    </div>
   
</dd>
 <dt class="accordion__title">Menu</dt>
  <dd class="accordion__content">
      <div class="settings">
    <br>
    
    <h2>Barra de Menu - Nomes</h2> 


   <div class="setting">
	   <label>Home:</label>
	   <input class="long" type="text" name="menu_home" value="<?php echo $menu_home; ?>"/>
   </div>
   <div class="setting">
	   <label>Sobre:</label>
	   <input class="long" type="text" name="menu_sobre" value="<?php echo $menu_sobre; ?>"/>
   </div>
   <div class="setting">
	   <label>Cardápio:</label>
	   <input class="long" type="text" name="menu_cardapio" value="<?php echo $menu_cardapio; ?>"/>
   </div>
      <div class="setting">
	   <label>Fotos:</label>
	   <input class="long" type="text" name="menu_fotos" value="<?php echo $menu_fotos; ?>"/>
   </div>
     <div class="setting">
	   <label>Blog:</label>
	   <input class="long" type="text" name="menu_blog" value="<?php echo $menu_blog; ?>"/>
   </div>
        <div class="setting">
	   <label>Contato:</label>
	   <input class="long" type="text" name="menu_contato" value="<?php echo $menu_contato; ?>"/>
   </div>
  
  </dd>

 
    </dl>

    <input name="custom_fieldname1" type="hidden" value="<?php echo $custom_fieldname1; ?>" >
    <input name="custom_fieldname2" type="hidden" value="<?php echo $custom_fieldname2; ?>" >
    <input name="formcap" type="hidden" value = "<?php echo $formcap; ?> ">
       
    <input type="hidden" name="status" value="1" />
    <input type="hidden" name="token" value="<?php echo $_SESSION["token"]; ?>" />
    
    </form>

        <script>
if($(window).width() > 768){

// Hide all but first tab content on larger viewports
$('.accordion__content:not(:first)').hide();

// Activate first tab
$('.accordion__title:first-child').addClass('active');

} else {
  
// Hide all content items on narrow viewports
$('.accordion__content').hide();
};

// Wrap a div around content to create a scrolling container which we're going to use on narrow viewports
$( ".accordion__content" ).wrapInner( "<div class='overflow-scrolling'></div>" );

// The clicking action
$('.accordion__title').on('click', function() {
$('.accordion__content').hide();
$(this).next().show().prev().addClass('active').siblings().removeClass('active');
});
</script>
    
    
<?php } ?>
</div>
</div>