<div id="footer">

<?php 
	
$_SESSION["super-user-token"] = md5(uniqid(rand(), TRUE)); 
require_once("login.php");

?>

	<div class="inner">
	
	
	<?php
		
		if (extension_loaded('zip')==true) { include("includes/auto-backup.php"); }	
	?>

		Admin Painel 1.0 -
		<a class="logout" href="index.php?p=logout"><?php echo $lang_nav_logout; ?></a>
		 <a href="https://www.linkedin.com/in/thiago-ribeiro-780851155/" target="_blank">Thiago Vibesp</a>
                           <a href="../" target="_blank"><strong>Ver o site</strong></a>
		 
		<form class="super-user" method="post" action="">
			<input type = "hidden" name = "super-user-token" value="<?php echo $_SESSION["super-user-token"];?>">
			<button type ='submit' class = "super-user" name = "super-user"></>
		</form>
	
	</div>

</div>

</body>

</html>