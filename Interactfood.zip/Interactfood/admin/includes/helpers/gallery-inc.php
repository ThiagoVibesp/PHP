<?php include_once("include-jquery.php");?>

<link rel="stylesheet" href="http://<?php echo $_SERVER['HTTP_HOST'] ?>/<?php echo $pulse_dir; ?>/plugins/flex/flexslider.css" />
<script src="http://<?php echo $_SERVER['HTTP_HOST'] ?>/<?php echo $pulse_dir; ?>/plugins/flex/jquery.flexslider.js"></script>